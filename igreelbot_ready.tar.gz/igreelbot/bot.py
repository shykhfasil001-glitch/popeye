"""
igreelbot Discord Bot
Manage Instagram accounts and scraping via Discord slash commands.

Setup:
1. Create Discord app at https://discord.com/developers/applications
2. Add DISCORD_BOT_TOKEN to .env
3. First run: python login.py   (saves Instagram session)
4. Then run:  python bot.py
"""

import json
import os
import threading
import time
from datetime import datetime
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "")
ACCOUNTS_FILE = Path(__file__).parent / "accounts.json"
SCRAPE_INTERVAL_HOURS = int(os.getenv("SCRAPE_INTERVAL_HOURS", "6"))
BOT_ADMIN_ROLE = os.getenv("BOT_ADMIN_ROLE", "")


# ── Accounts DB ───────────────────────────────────────────────────────────────

def load_accounts() -> dict:
    if ACCOUNTS_FILE.exists():
        with open(ACCOUNTS_FILE) as f:
            return json.load(f)
    return {}


def save_accounts(accounts: dict):
    with open(ACCOUNTS_FILE, "w") as f:
        json.dump(accounts, f, indent=2)


# ── Bot State ─────────────────────────────────────────────────────────────────

scraping_active = False
scraping_thread = None
last_scrape_time = None
scrape_status_message = "Not started yet"

# ── Bot Setup ─────────────────────────────────────────────────────────────────

intents = discord.Intents.default()
intents.message_content = True
bot = commands.Bot(command_prefix="!", intents=intents)
tree = bot.tree


def has_permission(interaction: discord.Interaction) -> bool:
    if not BOT_ADMIN_ROLE:
        return True
    if isinstance(interaction.user, discord.Member):
        return any(r.name == BOT_ADMIN_ROLE for r in interaction.user.roles)
    return False


# ── Scraper Runner ────────────────────────────────────────────────────────────

def run_scrape_once():
    global last_scrape_time, scrape_status_message
    try:
        scrape_status_message = "⏳ Scraping in progress..."
        import config
        from src.instaloader_scraper import scrape_account
        from src.distribution import apply_filters
        from src.report_generator import save_report
        from src.discord_sender import send_report_to_discord, send_full_report_embed

        accounts = load_accounts()
        if not accounts:
            scrape_status_message = "❌ No accounts configured"
            return

        all_results = {}
        for name, username in accounts.items():
            try:
                raw = scrape_account(username, max_posts=config.MAX_REELS_PER_ACCOUNT)
                all_results[name] = apply_filters(raw)
            except Exception as e:
                print(f"[Bot] Error scraping {name}: {e}")
                all_results[name] = []

        ts = datetime.now().strftime("%Y%m%d_%H%M")
        save_report(all_results, f"reels_report_{ts}.txt")
        send_full_report_embed(all_results)
        time.sleep(1)
        for name, reels in all_results.items():
            send_report_to_discord(name, reels)
            time.sleep(1)

        last_scrape_time = datetime.now()
        total = sum(len(v) for v in all_results.values())
        scrape_status_message = f"✅ {last_scrape_time.strftime('%Y-%m-%d %H:%M')} — {total} reels"
        print(f"[Bot] Scrape complete: {total} reels")

    except Exception as e:
        scrape_status_message = f"❌ Error: {str(e)[:120]}"
        print(f"[Bot] Scrape error: {e}")


def scrape_loop():
    global scraping_active
    while scraping_active:
        run_scrape_once()
        for _ in range(SCRAPE_INTERVAL_HOURS * 60):
            if not scraping_active:
                break
            time.sleep(60)


# ── Slash Commands ─────────────────────────────────────────────────────────────

@tree.command(name="add_account", description="Instagram account add karo")
@app_commands.describe(
    display_name="Report mein naam (e.g. IAN)",
    username="Instagram username (@ ke bina)"
)
async def add_account(interaction: discord.Interaction, display_name: str, username: str):
    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    accounts = load_accounts()
    name = display_name.upper().strip()
    user = username.strip().lstrip("@")

    if name in accounts:
        await interaction.response.send_message(
            f"⚠️ **{name}** already exists (`@{accounts[name]}`).\n`/edit_account` se change karo.",
            ephemeral=True
        )
        return

    accounts[name] = user
    save_accounts(accounts)

    embed = discord.Embed(title="✅ Account Added", color=0x00C851, timestamp=datetime.utcnow())
    embed.add_field(name="Display Name", value=f"**{name}**", inline=True)
    embed.add_field(name="Instagram", value=f"`@{user}`", inline=True)
    embed.add_field(name="Profile", value=f"https://instagram.com/{user}", inline=False)
    embed.set_footer(text=f"Total accounts: {len(accounts)}")
    await interaction.response.send_message(embed=embed)


@tree.command(name="remove_account", description="Instagram account remove karo")
@app_commands.describe(display_name="Display name (e.g. IAN)")
async def remove_account(interaction: discord.Interaction, display_name: str):
    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    accounts = load_accounts()
    name = display_name.upper().strip()

    if name not in accounts:
        await interaction.response.send_message(
            f"❌ **{name}** nahi mila. `/list_accounts` dekho.", ephemeral=True
        )
        return

    old_user = accounts.pop(name)
    save_accounts(accounts)

    embed = discord.Embed(
        title="🗑️ Account Removed",
        description=f"**{name}** (`@{old_user}`) remove ho gaya.",
        color=0xFF4444,
        timestamp=datetime.utcnow()
    )
    embed.set_footer(text=f"Remaining: {len(accounts)} accounts")
    await interaction.response.send_message(embed=embed)


@tree.command(name="edit_account", description="Account ka Instagram username change karo")
@app_commands.describe(
    display_name="Display name (e.g. IAN)",
    new_username="Naya Instagram username"
)
async def edit_account(interaction: discord.Interaction, display_name: str, new_username: str):
    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    accounts = load_accounts()
    name = display_name.upper().strip()
    new_user = new_username.strip().lstrip("@")

    if name not in accounts:
        await interaction.response.send_message(
            f"❌ **{name}** nahi mila. `/list_accounts` dekho.", ephemeral=True
        )
        return

    old_user = accounts[name]
    accounts[name] = new_user
    save_accounts(accounts)

    embed = discord.Embed(title="✏️ Account Updated", color=0xFFAA00, timestamp=datetime.utcnow())
    embed.add_field(name="Name", value=f"**{name}**", inline=False)
    embed.add_field(name="Purana", value=f"`@{old_user}`", inline=True)
    embed.add_field(name="Naya", value=f"`@{new_user}`", inline=True)
    await interaction.response.send_message(embed=embed)


@tree.command(name="rename_account", description="Display name change karo (e.g. IAN → KING)")
@app_commands.describe(old_name="Purana naam", new_name="Naya naam")
async def rename_account(interaction: discord.Interaction, old_name: str, new_name: str):
    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    accounts = load_accounts()
    old = old_name.upper().strip()
    new = new_name.upper().strip()

    if old not in accounts:
        await interaction.response.send_message(f"❌ **{old}** nahi mila.", ephemeral=True)
        return

    username = accounts.pop(old)
    accounts[new] = username
    save_accounts(accounts)

    await interaction.response.send_message(
        f"✅ **{old}** → **{new}** (`@{username}`) rename ho gaya!"
    )


@tree.command(name="list_accounts", description="Sab monitored accounts dekho")
async def list_accounts(interaction: discord.Interaction):
    accounts = load_accounts()

    embed = discord.Embed(
        title="📋 Monitored Instagram Accounts",
        color=0x833AB4,
        timestamp=datetime.utcnow()
    )

    if not accounts:
        embed.description = "Koi account nahi hai.\n`/add_account` se add karo."
    else:
        lines = [
            f"`{i}.` **{name}** → [@{user}](https://instagram.com/{user}/)"
            for i, (name, user) in enumerate(accounts.items(), 1)
        ]
        embed.description = "\n".join(lines)
        embed.set_footer(text=f"Total: {len(accounts)} accounts")

    await interaction.response.send_message(embed=embed)


@tree.command(name="start", description="Auto scraping shuru karo")
async def start_scraping(interaction: discord.Interaction):
    global scraping_active, scraping_thread

    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    if scraping_active:
        await interaction.response.send_message("⚠️ Bot pehle se chal raha hai! `/status` dekho.", ephemeral=True)
        return

    accounts = load_accounts()
    if not accounts:
        await interaction.response.send_message(
            "❌ Pehle `/add_account` se koi account add karo.", ephemeral=True
        )
        return

    scraping_active = True
    scraping_thread = threading.Thread(target=scrape_loop, daemon=True)
    scraping_thread.start()

    embed = discord.Embed(
        title="▶️ Bot Started",
        description=(
            f"**{len(accounts)}** accounts ki scraping shuru ho gayi!\n"
            f"Interval: har **{SCRAPE_INTERVAL_HOURS} ghante** mein\n\n"
            f"Accounts: {', '.join(f'`{n}`' for n in accounts)}"
        ),
        color=0x00C851,
        timestamp=datetime.utcnow()
    )
    await interaction.response.send_message(embed=embed)


@tree.command(name="stop", description="Auto scraping band karo")
async def stop_scraping(interaction: discord.Interaction):
    global scraping_active

    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    if not scraping_active:
        await interaction.response.send_message("⚠️ Bot pehle se band hai.", ephemeral=True)
        return

    scraping_active = False

    embed = discord.Embed(
        title="⏹️ Bot Stopped",
        description="Scraping band ho gayi.\n`/start` se dobara shuru karo.",
        color=0xFF4444,
        timestamp=datetime.utcnow()
    )
    await interaction.response.send_message(embed=embed)


@tree.command(name="run_now", description="Abhi ek baar scrape karo")
async def run_now(interaction: discord.Interaction):
    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    accounts = load_accounts()
    if not accounts:
        await interaction.response.send_message(
            "❌ Pehle `/add_account` se account add karo.", ephemeral=True
        )
        return

    await interaction.response.send_message(
        f"⏳ Scraping shuru ho rahi hai **{len(accounts)}** accounts ke liye...\nResults abhi aayenge!"
    )
    threading.Thread(target=run_scrape_once, daemon=True).start()


@tree.command(name="set_interval", description="Scraping ka interval change karo (ghante mein)")
@app_commands.describe(hours="Kitne ghante baad scrape kare (e.g. 3, 6, 12)")
async def set_interval(interaction: discord.Interaction, hours: int):
    global SCRAPE_INTERVAL_HOURS

    if not has_permission(interaction):
        await interaction.response.send_message("❌ Permission nahi hai.", ephemeral=True)
        return

    if hours < 1 or hours > 24:
        await interaction.response.send_message("❌ 1 se 24 ke beech value do.", ephemeral=True)
        return

    SCRAPE_INTERVAL_HOURS = hours
    restart_note = "\n⚠️ Interval apply karne ke liye `/stop` phir `/start` karo." if scraping_active else ""
    await interaction.response.send_message(
        f"✅ Interval set: har **{hours} ghante** mein scrape hoga.{restart_note}"
    )


@tree.command(name="status", description="Bot ka current status dekho")
async def status(interaction: discord.Interaction):
    accounts = load_accounts()
    color = 0x00C851 if scraping_active else 0x888888

    embed = discord.Embed(title="📊 Bot Status", color=color, timestamp=datetime.utcnow())
    embed.add_field(name="Status", value="🟢 Chal raha hai" if scraping_active else "🔴 Band hai", inline=True)
    embed.add_field(name="Accounts", value=str(len(accounts)), inline=True)
    embed.add_field(name="Interval", value=f"Har {SCRAPE_INTERVAL_HOURS}h", inline=True)
    embed.add_field(
        name="Last Scrape",
        value=last_scrape_time.strftime("%Y-%m-%d %H:%M") if last_scrape_time else "Kabhi nahi",
        inline=True
    )
    embed.add_field(name="Last Result", value=scrape_status_message, inline=False)

    if accounts:
        embed.add_field(
            name="Monitored Accounts",
            value="\n".join(f"**{n}** → `@{u}`" for n, u in accounts.items()),
            inline=False
        )

    await interaction.response.send_message(embed=embed)


@tree.command(name="help", description="Sab commands dekho")
async def help_command(interaction: discord.Interaction):
    embed = discord.Embed(
        title="🤖 igreelbot — Commands",
        description="Instagram Reels Tracker • Discord Bot",
        color=0x833AB4,
    )
    embed.add_field(
        name="👥 Account Management",
        value=(
            "`/add_account` — Account add karo\n"
            "`/remove_account` — Account hatao\n"
            "`/edit_account` — Username change karo\n"
            "`/rename_account` — Display name change karo\n"
            "`/list_accounts` — Sab accounts dekho"
        ),
        inline=False,
    )
    embed.add_field(
        name="⚙️ Bot Control",
        value=(
            "`/start` — Auto scraping shuru karo\n"
            "`/stop` — Scraping band karo\n"
            "`/run_now` — Abhi ek baar chalao\n"
            "`/set_interval` — Interval change karo\n"
            "`/status` — Status dekho"
        ),
        inline=False,
    )
    embed.set_footer(text="igreelbot • No API key needed • Powered by instaloader")
    await interaction.response.send_message(embed=embed)


# ── Events ────────────────────────────────────────────────────────────────────

@bot.event
async def on_ready():
    print(f"\n{'='*50}")
    print(f"  igreelbot Discord Bot")
    print(f"  Logged in as: {bot.user} (ID: {bot.user.id})")
    print(f"{'='*50}")
    try:
        synced = await tree.sync()
        print(f"  Synced {len(synced)} slash commands")
    except Exception as e:
        print(f"  Command sync failed: {e}")
    accounts = load_accounts()
    print(f"  Accounts loaded: {len(accounts)}")
    print("  Bot ready!\n")


# ── Main ──────────────────────────────────────────────────────────────────────

if __name__ == "__main__":
    if not BOT_TOKEN:
        print("\n❌ DISCORD_BOT_TOKEN .env mein set nahi hai!")
        print("   https://discord.com/developers/applications se lena hai\n")
        exit(1)
    print("Starting igreelbot Discord bot...")
    bot.run(BOT_TOKEN)
