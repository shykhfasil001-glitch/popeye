"""
diagnose.py — Sab check karo bot chalane se pehle.
Usage: python diagnose.py
"""
import sys
import os
from pathlib import Path


def check(label: str, ok: bool, detail: str = "") -> bool:
    status = "✅" if ok else "❌"
    msg = f"  {status} {label}"
    if detail:
        msg += f"  ({detail})"
    print(msg)
    return ok


def main():
    print("\n" + "=" * 50)
    print("  igreelbot — Diagnostics")
    print("=" * 50 + "\n")

    all_ok = True

    # Python version
    py = sys.version_info
    all_ok &= check("Python", py >= (3, 10), f"{py.major}.{py.minor}.{py.micro}")

    # Packages
    print("\nPackages:")
    for pkg, install_name in {
        "instaloader": "instaloader",
        "requests": "requests",
        "dotenv": "python-dotenv",
        "discord": "discord.py",
    }.items():
        try:
            __import__(pkg)
            all_ok &= check(pkg, True)
        except ImportError:
            all_ok &= check(pkg, False, f"pip install {install_name}")

    # .env file
    print("\nConfiguration:")
    env_path = Path(__file__).parent / ".env"
    has_env = env_path.exists()
    check(".env file", has_env, str(env_path) if has_env else "Nahi mila — .env.example copy karo")

    if has_env:
        from dotenv import load_dotenv
        load_dotenv(env_path)

    import config

    print("\nCredentials:")
    all_ok &= check(
        "INSTAGRAM_USERNAME",
        bool(config.INSTAGRAM_USERNAME),
        f"@{config.INSTAGRAM_USERNAME}" if config.INSTAGRAM_USERNAME else "Missing"
    )
    all_ok &= check(
        "INSTAGRAM_PASSWORD",
        bool(config.INSTAGRAM_PASSWORD),
        "Set" if config.INSTAGRAM_PASSWORD else "Missing"
    )
    all_ok &= check(
        "DISCORD_BOT_TOKEN",
        bool(config.DISCORD_BOT_TOKEN),
        "Set" if config.DISCORD_BOT_TOKEN else "Missing"
    )
    all_ok &= check(
        "DISCORD_WEBHOOK_URL",
        bool(config.DISCORD_WEBHOOK_URL),
        "Set" if config.DISCORD_WEBHOOK_URL else "Missing"
    )

    # Session file
    print("\nInstagram Session:")
    session_file = Path(__file__).parent / "session"
    has_session = session_file.exists()
    if has_session:
        check("Session file", True, "Saved session mila — login skip hoga")
    else:
        check("Session file", False, "Nahi mila — 'python login.py' chalao pehle!")
        all_ok = False

    # Accounts
    print("\nAccounts:")
    accounts_file = Path(__file__).parent / "accounts.json"
    if accounts_file.exists():
        import json
        with open(accounts_file) as f:
            accounts = json.load(f)
        if accounts:
            for name, user in accounts.items():
                check(f"{name}", bool(user), f"@{user}")
        else:
            check("accounts.json", False, "Empty — /add_account se add karo Discord mein")
    else:
        check("accounts.json", False, "Nahi mila — /add_account se add karo Discord mein")

    # Instagram connectivity test
    if config.INSTAGRAM_USERNAME and has_session:
        print("\nInstagram Connectivity:")
        try:
            import instaloader
            L = instaloader.Instaloader(quiet=True)
            L.load_session_from_file(config.INSTAGRAM_USERNAME, str(session_file))
            all_ok &= check("Instagram session", True, "Valid")
        except Exception as e:
            all_ok &= check("Instagram session", False, f"{e}")
            print("   → 'python login.py' dobara chalao")

    print("\n" + "=" * 50)
    if all_ok:
        print("  ✅ Sab theek hai! Ab chalao: python bot.py")
    else:
        print("  ❌ Kuch issues hain — upar fix karo phir dobara try karo")
    print("=" * 50 + "\n")
    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
