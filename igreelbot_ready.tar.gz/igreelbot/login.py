"""
login.py — Run this ONCE to save your Instagram session.
After this, bot.py will use the saved session (no password needed again).

Handles 2FA automatically.

Usage: python login.py
"""
import os
import sys
from pathlib import Path
from dotenv import load_dotenv
import instaloader

load_dotenv()

SESSION_FILE = Path(__file__).parent / "session"
USERNAME = os.getenv("INSTAGRAM_USERNAME", "")
PASSWORD = os.getenv("INSTAGRAM_PASSWORD", "")


def main():
    print("\n" + "=" * 50)
    print("  igreelbot — Instagram Login")
    print("=" * 50 + "\n")

    username = USERNAME or input("Instagram username: ").strip()
    password = PASSWORD or input("Instagram password: ").strip()

    if not username or not password:
        print("❌ Username or password is empty.")
        sys.exit(1)

    L = instaloader.Instaloader(quiet=True)

    print(f"\nLogging in as @{username} ...")

    try:
        L.login(username, password)
        L.save_session_to_file(str(SESSION_FILE))
        print(f"✅ Login successful!")
        print(f"✅ Session saved to: {SESSION_FILE}")
        print("\nYou can now run: python bot.py\n")

    except instaloader.exceptions.BadCredentialsException:
        print("❌ Wrong username or password. Check your .env file.")
        sys.exit(1)

    except instaloader.exceptions.TwoFactorAuthRequiredException:
        print("📱 2FA code required.")
        code = input("Enter the 2FA code from your authenticator app: ").strip()
        try:
            L.two_factor_login(code)
            L.save_session_to_file(str(SESSION_FILE))
            print(f"✅ 2FA login successful!")
            print(f"✅ Session saved to: {SESSION_FILE}")
            print("\nYou can now run: python bot.py\n")
        except Exception as e:
            print(f"❌ 2FA failed: {e}")
            sys.exit(1)

    except instaloader.exceptions.ConnectionException as e:
        print(f"❌ Connection error: {e}")
        print("Check your internet connection and try again.")
        sys.exit(1)

    except Exception as e:
        print(f"❌ Login failed: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()
