"""
igreelbot — CLI runner
Usage:
    python main.py               # Run once
    python main.py --no-discord  # Run without Discord
    python main.py --accounts IAN SLAYER
"""
import sys
import time
import argparse
from datetime import datetime

import config
from src.instaloader_scraper import scrape_account, ReelData
from src.distribution import apply_filters
from src.report_generator import save_report, print_report
from src.discord_sender import send_report_to_discord, send_full_report_embed


def parse_args():
    parser = argparse.ArgumentParser(description="igreelbot — Instagram Reels Tracker")
    parser.add_argument("--no-discord", action="store_true", help="Skip Discord")
    parser.add_argument("--accounts", nargs="+", default=None)
    parser.add_argument("--max-reels", type=int, default=config.MAX_REELS_PER_ACCOUNT)
    parser.add_argument("--min-likes", type=int, default=config.MIN_LIKES_THRESHOLD)
    parser.add_argument("--output", type=str, default=config.REPORT_OUTPUT_FILE)
    return parser.parse_args()


def run(args, accounts: dict) -> dict[str, list[ReelData]]:
    if args.accounts:
        requested = {a.upper() for a in args.accounts}
        accounts = {k: v for k, v in accounts.items() if k.upper() in requested}

    if not accounts:
        print("[ERROR] No accounts configured.")
        sys.exit(1)

    config.MIN_LIKES_THRESHOLD = args.min_likes
    config.MAX_REELS_PER_ACCOUNT = args.max_reels

    all_results: dict[str, list[ReelData]] = {}

    for display_name, username in accounts.items():
        if not username:
            print(f"[SKIP] {display_name}: no username set")
            continue
        print(f"\n{'='*60}\nProcessing: {display_name} (@{username})\n{'='*60}")
        try:
            raw = scrape_account(username, max_posts=args.max_reels)
            filtered = apply_filters(raw)
            all_results[display_name] = filtered
            print(f"[OK] {display_name}: {len(filtered)} reels")
        except Exception as e:
            print(f"[ERROR] {display_name}: {e}")
            all_results[display_name] = []

    return all_results


def main():
    args = parse_args()

    # Load accounts from accounts.json (set by Discord bot) or config
    import json
    from pathlib import Path

    accounts_file = Path(__file__).parent / "accounts.json"
    if accounts_file.exists():
        with open(accounts_file) as f:
            accounts = json.load(f)
    else:
        accounts = {
            k: v for k, v in {
                "IAN": config.INSTAGRAM_USERNAME,
            }.items() if v
        }

    print(f"\n{'='*60}")
    print(f"igreelbot — {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Accounts: {list(accounts.keys())} | Max: {args.max_reels} | Min likes: {args.min_likes}")
    print(f"{'='*60}\n")

    all_results = run(args, accounts)
    print_report(all_results)
    output_path = save_report(all_results, args.output)
    print(f"\n[OK] Report saved: {output_path}")

    if config.SEND_TO_DISCORD and not args.no_discord:
        print("\n[Discord] Sending reports...")
        send_full_report_embed(all_results)
        time.sleep(1)
        for name, reels in all_results.items():
            send_report_to_discord(name, reels)
            time.sleep(1)
        print("[Discord] Done")

    print(f"\n[DONE] {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    main()
