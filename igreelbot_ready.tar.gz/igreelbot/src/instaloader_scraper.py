"""
Instagram scraper using instaloader — no API key needed.
Uses your Instagram session (cookies) to fetch reel metrics.
"""
import instaloader
from datetime import datetime
from dataclasses import dataclass
from typing import Optional
from pathlib import Path
import config

SESSION_FILE = Path(__file__).parent.parent / "session"


@dataclass
class ReelData:
    url: str
    shortcode: str
    views: int = 0
    likes: int = 0
    comments: int = 0
    duration_seconds: int = 0
    posted_at: Optional[datetime] = None
    er: float = 0.0
    followers: int = 0
    username: str = ""
    caption: str = ""

    @property
    def length_str(self) -> str:
        mins = self.duration_seconds // 60
        secs = self.duration_seconds % 60
        return f"{mins:02d}:{secs:02d}"

    @property
    def posted_str(self) -> str:
        if self.posted_at:
            return self.posted_at.strftime("%Y-%m-%d %H:%M")
        return "N/A"

    @property
    def likes_str(self) -> str:
        return f"{self.likes:,}"

    def to_report_line(self) -> str:
        return (
            f"{self.url} "
            f"[Views: {self.views:,} | "
            f"Likes: {self.likes_str} | "
            f"Comments: {self.comments:,} | "
            f"ER: {self.er:.1f}% | "
            f"Length: {self.length_str} | "
            f"Posted: {self.posted_str}]"
        )


def _get_loader() -> instaloader.Instaloader:
    """Create and return an authenticated Instaloader instance."""
    L = instaloader.Instaloader(
        download_pictures=False,
        download_videos=False,
        download_video_thumbnails=False,
        download_geotags=False,
        download_comments=False,
        save_metadata=False,
        compress_json=False,
        quiet=True,
    )

    # Try loading existing session first
    if SESSION_FILE.exists():
        try:
            L.load_session_from_file(config.INSTAGRAM_USERNAME, str(SESSION_FILE))
            print(f"[Instaloader] Loaded session for @{config.INSTAGRAM_USERNAME}")
            return L
        except Exception as e:
            print(f"[Instaloader] Could not load session: {e}")

    # Login with credentials
    if config.INSTAGRAM_USERNAME and config.INSTAGRAM_PASSWORD:
        print(f"[Instaloader] Logging in as @{config.INSTAGRAM_USERNAME} ...")
        try:
            L.login(config.INSTAGRAM_USERNAME, config.INSTAGRAM_PASSWORD)
            L.save_session_to_file(str(SESSION_FILE))
            print("[Instaloader] Login successful, session saved")
        except instaloader.exceptions.BadCredentialsException:
            raise RuntimeError("Invalid Instagram username or password in .env")
        except instaloader.exceptions.TwoFactorAuthRequiredException:
            raise RuntimeError(
                "2FA is enabled on your Instagram account.\n"
                "Run: python login.py — to login once and save session."
            )
        except Exception as e:
            raise RuntimeError(f"Instagram login failed: {e}")
    else:
        print("[Instaloader] No credentials set — running without login (limited data)")

    return L


def scrape_account(username: str, max_posts: int = 50) -> list[ReelData]:
    """
    Scrape Instagram posts/reels for a given username.
    Returns list of ReelData sorted by likes (descending).
    """
    print(f"\n[Scraper] Fetching posts for @{username} ...")

    L = _get_loader()

    try:
        profile = instaloader.Profile.from_username(L.context, username)
    except instaloader.exceptions.ProfileNotExistsException:
        raise RuntimeError(f"Instagram profile @{username} does not exist")
    except Exception as e:
        raise RuntimeError(f"Could not fetch profile @{username}: {e}")

    followers = profile.followers
    print(f"[Scraper] @{username} — {followers:,} followers, fetching up to {max_posts} posts...")

    reels: list[ReelData] = []
    count = 0

    try:
        for post in profile.get_posts():
            if count >= max_posts:
                break

            # Only process videos/reels
            if not post.is_video:
                count += 1
                continue

            shortcode = post.shortcode
            url = f"https://www.instagram.com/p/{shortcode}/"

            likes = post.likes if post.likes is not None else 0
            comments_count = post.comments if post.comments is not None else 0
            views = post.video_view_count if post.video_view_count is not None else 0
            duration = int(post.video_duration) if post.video_duration else 0

            posted_at = post.date_local if post.date_local else post.date_utc

            er = 0.0
            if followers > 0:
                er = round(((likes + comments_count) / followers) * 100, 2)

            caption = ""
            try:
                caption = post.caption[:200] if post.caption else ""
            except Exception:
                pass

            reel = ReelData(
                url=url,
                shortcode=shortcode,
                views=views,
                likes=likes,
                comments=comments_count,
                duration_seconds=duration,
                posted_at=posted_at,
                er=er,
                followers=followers,
                username=username,
                caption=caption,
            )
            reels.append(reel)
            count += 1

            if len(reels) % 10 == 0:
                print(f"[Scraper] Fetched {len(reels)} videos so far...")

    except Exception as e:
        print(f"[Scraper] Error while fetching posts for @{username}: {e}")
        if reels:
            print(f"[Scraper] Returning {len(reels)} reels fetched so far")

    # Sort by likes descending
    reels.sort(key=lambda r: r.likes, reverse=True)
    print(f"[Scraper] Done — {len(reels)} videos found for @{username}")
    return reels
