import time
import requests
from datetime import datetime, timezone
from dataclasses import dataclass, field
from typing import Optional
import config

APIFY_BASE = "https://api.apify.com/v2"

# Apify Actor ID for Instagram scraper (supports full metrics)
INSTAGRAM_SCRAPER_ACTOR = "apify/instagram-scraper"


@dataclass
class ReelData:
    url: str
    shortcode: str
    views: int = 0
    likes: int = 0
    comments: int = 0
    duration_seconds: int = 0
    posted_at: Optional[datetime] = None
    er: float = 0.0
    followers: int = 0
    username: str = ""
    caption: str = ""

    @property
    def length_str(self) -> str:
        mins = self.duration_seconds // 60
        secs = self.duration_seconds % 60
        return f"{mins:02d}:{secs:02d}"

    @property
    def posted_str(self) -> str:
        if self.posted_at:
            return self.posted_at.strftime("%Y-%m-%d %H:%M")
        return "N/A"

    @property
    def likes_str(self) -> str:
        if self.likes >= 1000:
            return f"{self.likes:,}"
        return str(self.likes)

    def to_report_line(self) -> str:
        return (
            f"{self.url} "
            f"[Views: {self.views:,} | "
            f"Likes: {self.likes_str} | "
            f"Comments: {self.comments:,} | "
            f"ER: {self.er:.1f}% | "
            f"Length: {self.length_str} | "
            f"Posted: {self.posted_str}]"
        )


def _run_apify_actor(username: str, max_posts: int) -> list[dict]:
    """Run Apify Instagram scraper actor and return raw results."""
    headers = {"Authorization": f"Bearer {config.APIFY_API_TOKEN}"}

    # Start the actor run
    run_input = {
        "directUrls": [f"https://www.instagram.com/{username}/"],
        "resultsType": "posts",
        "resultsLimit": max_posts,
        "addParentData": False,
        "searchType": "user",
        "searchLimit": 1,
    }

    print(f"  [Apify] Starting scrape for @{username} ...")
    resp = requests.post(
        f"{APIFY_BASE}/acts/{INSTAGRAM_SCRAPER_ACTOR}/runs",
        json=run_input,
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    run_id = resp.json()["data"]["id"]
    print(f"  [Apify] Run started: {run_id}")

    # Poll until finished
    for attempt in range(60):
        time.sleep(5)
        status_resp = requests.get(
            f"{APIFY_BASE}/actor-runs/{run_id}",
            headers=headers,
            timeout=15,
        )
        status_resp.raise_for_status()
        run_data = status_resp.json()["data"]
        status = run_data["status"]
        print(f"  [Apify] Status: {status} (attempt {attempt + 1})")

        if status == "SUCCEEDED":
            dataset_id = run_data["defaultDatasetId"]
            return _fetch_dataset(dataset_id, headers)
        elif status in ("FAILED", "ABORTED", "TIMED-OUT"):
            raise RuntimeError(f"Apify run {run_id} ended with status: {status}")

    raise TimeoutError(f"Apify run {run_id} timed out after polling")


def _fetch_dataset(dataset_id: str, headers: dict) -> list[dict]:
    """Fetch all items from an Apify dataset."""
    resp = requests.get(
        f"{APIFY_BASE}/datasets/{dataset_id}/items",
        params={"clean": "true", "format": "json"},
        headers=headers,
        timeout=30,
    )
    resp.raise_for_status()
    return resp.json()


def _get_followers(username: str, headers: dict) -> int:
    """Try to get follower count for ER calculation."""
    try:
        resp = requests.get(
            f"{APIFY_BASE}/acts/apify~instagram-profile-scraper/runs",
            json={"usernames": [username]},
            headers=headers,
            timeout=20,
        )
        # Fallback: return 0 if profile scrape not feasible
        return 0
    except Exception:
        return 0


def _parse_item(item: dict, followers: int, username: str) -> Optional[ReelData]:
    """Parse a raw Apify item into a ReelData object."""
    # Only process reels/videos
    media_type = item.get("type", item.get("mediaType", ""))
    is_video = (
        media_type in ("Video", "video", "GraphVideo")
        or item.get("isVideo", False)
        or item.get("videoDuration") is not None
    )

    url = item.get("url", item.get("displayUrl", ""))
    shortcode = item.get("shortCode", item.get("id", ""))

    # Build proper Instagram URL
    if shortcode and "instagram.com" not in url:
        url = f"https://www.instagram.com/p/{shortcode}/"

    if not url:
        return None

    likes = int(item.get("likesCount", item.get("likes", 0)) or 0)
    comments_count = int(item.get("commentsCount", item.get("comments", 0)) or 0)
    views = int(item.get("videoViewCount", item.get("videoPlayCount", item.get("views", 0))) or 0)
    duration = int(item.get("videoDuration", 0) or 0)

    # Parse timestamp
    posted_at = None
    timestamp = item.get("timestamp", item.get("takenAtTimestamp", item.get("taken_at_timestamp")))
    if timestamp:
        try:
            if isinstance(timestamp, (int, float)):
                posted_at = datetime.fromtimestamp(timestamp, tz=timezone.utc).replace(tzinfo=None)
            else:
                posted_at = datetime.fromisoformat(str(timestamp).replace("Z", "+00:00")).replace(tzinfo=None)
        except Exception:
            pass

    # Calculate ER
    er = 0.0
    if followers > 0:
        er = round(((likes + comments_count) / followers) * 100, 2)

    return ReelData(
        url=url,
        shortcode=shortcode,
        views=views,
        likes=likes,
        comments=comments_count,
        duration_seconds=duration,
        posted_at=posted_at,
        er=er,
        followers=followers,
        username=username,
        caption=item.get("caption", "")[:200] if item.get("caption") else "",
    )


def scrape_account(username: str, max_posts: int = 50) -> list[ReelData]:
    """
    Scrape Instagram reels for a given username.
    Returns list of ReelData sorted by likes (descending).
    """
    if not config.APIFY_API_TOKEN:
        raise ValueError("APIFY_API_TOKEN not set in .env")

    print(f"\n[Scraper] Fetching reels for @{username} ...")
    raw_items = _run_apify_actor(username, max_posts)
    print(f"[Scraper] Got {len(raw_items)} raw items from Apify")

    headers = {"Authorization": f"Bearer {config.APIFY_API_TOKEN}"}
    followers = _get_followers(username, headers)

    reels = []
    for item in raw_items:
        parsed = _parse_item(item, followers, username)
        if parsed:
            reels.append(parsed)

    # Sort by likes descending
    reels.sort(key=lambda r: r.likes, reverse=True)
    print(f"[Scraper] Parsed {len(reels)} reels/videos for @{username}")
    return reels
