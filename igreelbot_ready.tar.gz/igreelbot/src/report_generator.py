"""
Report generator — creates the .txt report in the same format as the sample:
ACCOUNT'S VIDEOS:
https://... [Views: X | Likes: X | Comments: X | ER: X% | Length: MM:SS | Posted: YYYY-MM-DD HH:MM]
"""
from datetime import datetime
from src.apify_scraper import ReelData
import config


def generate_report(all_accounts: dict[str, list[ReelData]]) -> str:
    """Generate a full report string for all accounts."""
    lines = []
    report_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines.append(f"# REELS REPORT — Generated: {report_time}")
    lines.append(f"# Lookback: {config.HOURS_LOOKBACK}h | Min Likes: {config.MIN_LIKES_THRESHOLD}")
    lines.append("")

    for account_name, reels in all_accounts.items():
        lines.append(f"{account_name.upper()}'S VIDEOS:")
        if not reels:
            lines.append("  (no reels found)")
        else:
            for reel in reels:
                lines.append(reel.to_report_line())
        lines.append("")

    return "\n".join(lines)


def save_report(all_accounts: dict[str, list[ReelData]], output_path: str = None) -> str:
    """Save report to a .txt file and return the path."""
    output_path = output_path or config.REPORT_OUTPUT_FILE
    content = generate_report(all_accounts)

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(content)

    print(f"[Report] Saved to: {output_path}")
    return output_path


def print_report(all_accounts: dict[str, list[ReelData]]) -> None:
    """Print report to stdout."""
    print("\n" + "=" * 70)
    print(generate_report(all_accounts))
    print("=" * 70)
