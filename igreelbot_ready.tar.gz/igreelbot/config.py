import os
from dotenv import load_dotenv

load_dotenv()

# === Instagram Login ===
INSTAGRAM_USERNAME = os.getenv("INSTAGRAM_USERNAME", "")
INSTAGRAM_PASSWORD = os.getenv("INSTAGRAM_PASSWORD", "")

# === Discord Bot Token ===
DISCORD_BOT_TOKEN = os.getenv("DISCORD_BOT_TOKEN", "")

# === Discord Webhook (for sending reports) ===
DISCORD_WEBHOOK_URL = os.getenv("DISCORD_WEBHOOK_URL", "")

# === Scraper Settings ===
MAX_REELS_PER_ACCOUNT = int(os.getenv("MAX_REELS", "50"))
MIN_LIKES_THRESHOLD = int(os.getenv("MIN_LIKES", "0"))
HOURS_LOOKBACK = int(os.getenv("HOURS_LOOKBACK", "24"))

# === Report Settings ===
REPORT_OUTPUT_FILE = os.getenv("REPORT_FILE", "reels_report.txt")
SEND_TO_DISCORD = os.getenv("SEND_TO_DISCORD", "true").lower() == "true"

# === Bot Settings ===
SCRAPE_INTERVAL_HOURS = int(os.getenv("SCRAPE_INTERVAL_HOURS", "6"))
BOT_ADMIN_ROLE = os.getenv("BOT_ADMIN_ROLE", "")
