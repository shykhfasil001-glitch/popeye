# igreelbot — Instagram Reels Tracker

Instagram Reels scraper with Discord bot control.
**No API key needed** — sirf apna Instagram account chahiye!

---

## Discord Bot Commands

| Command | Kaam |
|---------|------|
| `/add_account` | Account add karo |
| `/remove_account` | Account hatao |
| `/edit_account` | Username change karo |
| `/rename_account` | Display name change karo |
| `/list_accounts` | Sab accounts dekho |
| `/start` | Auto scraping shuru karo |
| `/stop` | Scraping band karo |
| `/run_now` | Abhi ek baar scrape karo |
| `/set_interval` | Interval change karo (ghante mein) |
| `/status` | Bot status dekho |
| `/help` | Sab commands |

---

## Report Format

```
IAN'S VIDEOS:
https://www.instagram.com/p/XYZ/ [Views: 50,000 | Likes: 42,258 | Comments: 320 | ER: 2.5% | Length: 00:30 | Posted: 2026-07-01 18:45]
```

---

## Setup (Step by Step)

### 1. Install karo
```bash
pip install -r requirements.txt
```

### 2. .env file banao
```bash
cp .env.example .env
# .env mein fill karo:
# INSTAGRAM_USERNAME, INSTAGRAM_PASSWORD
# DISCORD_BOT_TOKEN, DISCORD_WEBHOOK_URL
```

### 3. Instagram mein login karo (ek baar)
```bash
python login.py
```
> Yeh ek `session` file save karta hai. Dubara login nahi karna padega.

### 4. Sab check karo
```bash
python diagnose.py
```

### 5. Bot chalao
```bash
python bot.py
```

### 6. Discord mein use karo
```
/add_account IAN    reels_account_username
/add_account SLAYER another_username
/start
```

---

## Discord Bot Setup

1. **https://discord.com/developers/applications** → New Application
2. **Bot** section → Add Bot → Token copy karo
3. **Privileged Intents** → Message Content Intent ON
4. **OAuth2 → URL Generator**:
   - Scopes: `bot` + `applications.commands`
   - Permissions: Send Messages, Embed Links, Attach Files
5. Generated URL se bot ko server mein invite karo

---

## File Structure

```
igreelbot/
├── bot.py                     ← Discord bot (main file)
├── login.py                   ← Instagram login (ek baar chalao)
├── main.py                    ← CLI runner
├── config.py                  ← Settings
├── diagnose.py                ← Pre-run checks
├── accounts.json              ← Accounts DB (bot banata hai)
├── session                    ← Instagram session (login.py banata hai)
├── requirements.txt
├── .env                       ← Aapki credentials
├── .env.example               ← Template
└── src/
    ├── instaloader_scraper.py ← Instagram scraping (no API needed!)
    ├── discord_sender.py      ← Discord webhook
    ├── distribution.py        ← Filtering & sorting
    └── report_generator.py    ← Report formatter
```
