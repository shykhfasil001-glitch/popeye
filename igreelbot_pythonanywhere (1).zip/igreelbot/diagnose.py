"""
diagnose.py — Check that all dependencies and credentials are properly set up.
Run this before running main.py to catch issues early.

Usage: python diagnose.py
"""
import sys
import os


def check(label: str, ok: bool, detail: str = "") -> bool:
    status = "✅" if ok else "❌"
    print(f"  {status} {label}", end="")
    if detail:
        print(f"  ({detail})", end="")
    print()
    return ok


def main():
    print("\n" + "=" * 50)
    print("  igreelbot — Diagnostics")
    print("=" * 50 + "\n")

    all_ok = True

    # Check Python version
    py_ver = sys.version_info
    ok = py_ver >= (3, 10)
    all_ok &= check(
        "Python version",
        ok,
        f"{py_ver.major}.{py_ver.minor}.{py_ver.micro} {'✓' if ok else '(need 3.10+)'}",
    )

    # Check required packages
    print("\nPackages:")
    packages = {
        "requests": "HTTP requests",
        "dotenv": "python-dotenv for .env loading",
    }
    for pkg, desc in packages.items():
        try:
            __import__(pkg)
            all_ok &= check(pkg, True, desc)
        except ImportError:
            all_ok &= check(pkg, False, f"Missing — run: pip install {pkg}")

    # Check .env file
    print("\nConfiguration:")
    env_path = os.path.join(os.path.dirname(__file__), ".env")
    has_env = os.path.exists(env_path)
    check(".env file", has_env, env_path if has_env else "Not found — copy .env.example to .env")

    if has_env:
        from dotenv import load_dotenv
        load_dotenv(env_path)

    import config

    # Check API credentials
    print("\nCredentials:")
    all_ok &= check(
        "APIFY_API_TOKEN",
        bool(config.APIFY_API_TOKEN),
        "Set" if config.APIFY_API_TOKEN else "Missing in .env",
    )
    all_ok &= check(
        "DISCORD_WEBHOOK_URL",
        bool(config.DISCORD_WEBHOOK_URL),
        "Set" if config.DISCORD_WEBHOOK_URL else "Missing in .env",
    )

    # Check accounts
    print("\nAccounts:")
    any_account = False
    for name, username in config.INSTAGRAM_ACCOUNTS.items():
        ok = bool(username)
        any_account = any_account or ok
        check(f"ACCOUNT_{name}", ok, f"@{username}" if ok else "Not set")

    if not any_account:
        print("  ❌ No accounts set — add at least one in .env")
        all_ok = False

    # Test Apify connectivity (if token set)
    if config.APIFY_API_TOKEN:
        print("\nConnectivity:")
        try:
            import requests
            resp = requests.get(
                "https://api.apify.com/v2/users/me",
                headers={"Authorization": f"Bearer {config.APIFY_API_TOKEN}"},
                timeout=10,
            )
            if resp.status_code == 200:
                data = resp.json().get("data", {})
                username = data.get("username", "unknown")
                plan = data.get("plan", {}).get("id", "unknown")
                all_ok &= check("Apify API", True, f"Logged in as: {username} (plan: {plan})")
            else:
                all_ok &= check("Apify API", False, f"HTTP {resp.status_code} — check your token")
        except Exception as e:
            all_ok &= check("Apify API", False, f"Connection error: {e}")

        # Test Discord webhook
        if config.DISCORD_WEBHOOK_URL:
            try:
                import requests
                resp = requests.get(config.DISCORD_WEBHOOK_URL, timeout=10)
                all_ok &= check(
                    "Discord Webhook",
                    resp.status_code == 200,
                    "Valid" if resp.status_code == 200 else f"HTTP {resp.status_code}",
                )
            except Exception as e:
                all_ok &= check("Discord Webhook", False, f"Connection error: {e}")

    print("\n" + "=" * 50)
    if all_ok:
        print("  ✅ All checks passed! Ready to run: python main.py")
    else:
        print("  ❌ Some checks failed. Fix the issues above before running.")
    print("=" * 50 + "\n")

    sys.exit(0 if all_ok else 1)


if __name__ == "__main__":
    main()
