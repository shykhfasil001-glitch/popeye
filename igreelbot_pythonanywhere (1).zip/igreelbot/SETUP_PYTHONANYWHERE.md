# igreelbot — PythonAnywhere Deployment Guide

## Step 1: Upload Files

1. Log in to https://www.pythonanywhere.com
2. Go to **Files** tab → Upload the zip file
3. Open a **Bash console** and run:
```bash
cd ~ && unzip igreelbot_pythonanywhere.zip
```

## Step 2: Install Dependencies

```bash
cd igreelbot && pip install -r requirements.txt
```

## Step 3: Create Your .env File

```bash
cp .env.example .env && nano .env
```

Fill in:
```
DISCORD_BOT_TOKEN=your_bot_token_here
APIFY_API_TOKEN=your_apify_token_here
```

> Webhook URL is already saved in `settings.json` — no need to add it here.

Save: `Ctrl+O` → Enter → `Ctrl+X`

## Step 4: Test the Setup

```bash
python diagnose.py
```

## Step 5: Run the Bot (Always-On Task)

> ⚠️ Always-On Tasks require a **paid PythonAnywhere account**.

1. Go to **Tasks** tab → **Always-on task**
2. Command:
```
bash -c "cd /home/<your_username>/igreelbot && python discord_bot.py"
```

## Free Account Workaround

Run manually in Bash console (keep tab open):
```bash
cd igreelbot && python discord_bot.py
```

---

## Discord Commands (Quick Reference)

| Command | Description |
|---|---|
| `!run` | Start the scraper |
| `!stop` | Stop the scraper |
| `!status` | Show bot status |
| `!add <username>` | Add Instagram account |
| `!remove <username>` | Remove account |
| `!replace <old> <new>` | Edit/rename account |
| `!list [page]` | List all accounts (20 per page) |
| `!clearall confirm` | Clear all accounts |
| `!settings` | View current settings |
| `!setkey <token>` | Update Apify key (use in DMs!) |
| `!setwebhook <url>` | Update webhook URL |
| `!setmaxreels <n>` | Max reels per account |
| `!setminlikes <n>` | Min likes filter |
| `!sethours <n>` | Lookback window in hours |
| `!help` | Full command list |
