from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from src.apify_scraper import ReelData
import config

CET = ZoneInfo("Europe/Berlin")  # CET (UTC+1) / CEST (UTC+2), DST-aware


def filter_recent(reels: list[ReelData], hours: int = None) -> list[ReelData]:
    """Filter reels posted within the last N hours (CET-based window)."""
    hours = hours or config.HOURS_LOOKBACK
    now_cet = datetime.now(tz=CET)
    cutoff_cet = now_cet - timedelta(hours=hours)
    # Convert to naive UTC for comparison (posted_at is stored as naive UTC)
    cutoff = cutoff_cet.astimezone(timezone.utc).replace(tzinfo=None)
    filtered = [
        r for r in reels
        if r.posted_at is None or r.posted_at >= cutoff
    ]
    print(f"[Filter] {len(filtered)}/{len(reels)} reels within last {hours}h")
    return filtered


def filter_by_likes(reels: list[ReelData], min_likes: int = None) -> list[ReelData]:
    """Filter reels with at least min_likes likes."""
    min_likes = min_likes if min_likes is not None else config.MIN_LIKES_THRESHOLD
    if min_likes <= 0:
        return reels
    filtered = [r for r in reels if r.likes >= min_likes]
    print(f"[Filter] {len(filtered)}/{len(reels)} reels with >= {min_likes} likes")
    return filtered


def sort_by_likes(reels: list[ReelData]) -> list[ReelData]:
    """Sort reels by likes descending."""
    return sorted(reels, key=lambda r: r.likes, reverse=True)


def sort_by_views(reels: list[ReelData]) -> list[ReelData]:
    """Sort reels by views descending."""
    return sorted(reels, key=lambda r: r.views, reverse=True)


def sort_by_er(reels: list[ReelData]) -> list[ReelData]:
    """Sort reels by engagement rate descending."""
    return sorted(reels, key=lambda r: r.er, reverse=True)


def deduplicate(reels: list[ReelData]) -> list[ReelData]:
    """Remove duplicate reels by URL."""
    seen = set()
    unique = []
    for r in reels:
        if r.url not in seen:
            seen.add(r.url)
            unique.append(r)
    return unique


def apply_filters(reels: list[ReelData]) -> list[ReelData]:
    """Apply all standard filters in order."""
    reels = deduplicate(reels)
    reels = filter_recent(reels)
    reels = filter_by_likes(reels)
    reels = sort_by_likes(reels)
    # Cap to MAX_REELS_PER_ACCOUNT — only show first N within 24h
    limit = config.MAX_REELS_PER_ACCOUNT
    if len(reels) > limit:
        reels = reels[:limit]
        print(f"[Filter] Capped to {limit} reels")
    return reels
