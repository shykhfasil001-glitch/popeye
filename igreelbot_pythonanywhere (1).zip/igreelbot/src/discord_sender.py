import requests
from datetime import datetime
from src.apify_scraper import ReelData
import config


def _chunk_list(lst: list, size: int) -> list[list]:
    """Split a list into chunks of given size."""
    return [lst[i:i + size] for i in range(0, len(lst), size)]


def send_report_to_discord(
    account_name: str,
    reels: list[ReelData],
    webhook_url: str = None,
) -> bool:
    """
    Send a formatted reels report to a Discord channel via webhook.
    Sends multiple messages if report is too long.
    """
    url = webhook_url or config.DISCORD_WEBHOOK_URL
    if not url:
        print("[Discord] No webhook URL set, skipping Discord send")
        return False

    if not reels:
        print(f"[Discord] No reels to send for {account_name}")
        return False

    top_reel = reels[0]
    total_likes = sum(r.likes for r in reels)
    avg_likes = total_likes // len(reels) if reels else 0

    # Build header embed
    header_embed = {
        "title": f"📊 {account_name}'S REELS REPORT",
        "color": 0x833AB4,
        "description": (
            f"**Total Videos:** {len(reels)}\n"
            f"**Total Likes:** {total_likes:,}\n"
            f"**Avg Likes:** {avg_likes:,}\n"
            f"**Top Video:** [{top_reel.likes:,} likes]({top_reel.url})"
        ),
        "timestamp": datetime.utcnow().isoformat(),
        "footer": {"text": "igreelbot • Instagram Reels Tracker"},
    }

    _send_webhook(url, embeds=[header_embed])

    # Send reels in chunks of 10 per message (Discord embed limit)
    for chunk in _chunk_list(reels, 10):
        lines = []
        for i, reel in enumerate(chunk, 1):
            lines.append(reel.to_report_line())

        content = "\n".join(lines)

        # Split if > 2000 chars (Discord message limit)
        if len(content) > 1900:
            # Send as file instead
            _send_as_file(url, account_name, content)
        else:
            _send_webhook(url, content=f"```\n{content}\n```")

    return True


def send_full_report_embed(
    all_accounts: dict[str, list[ReelData]],
    webhook_url: str = None,
) -> bool:
    """Send a combined summary embed for all accounts."""
    url = webhook_url or config.DISCORD_WEBHOOK_URL
    if not url:
        return False

    embeds = []
    for account_name, reels in all_accounts.items():
        if not reels:
            continue

        top5 = reels[:5]
        top5_lines = "\n".join(
            f"`#{i+1}` [{r.likes:,} likes]({r.url}) — {r.posted_str}"
            for i, r in enumerate(top5)
        )

        embed = {
            "title": f"🎬 {account_name}'S TOP VIDEOS",
            "color": _account_color(account_name),
            "description": top5_lines or "No reels found",
            "fields": [
                {
                    "name": "📈 Stats",
                    "value": (
                        f"Total: {len(reels)} videos\n"
                        f"Total Likes: {sum(r.likes for r in reels):,}\n"
                        f"Best ER: {max((r.er for r in reels), default=0):.1f}%"
                    ),
                    "inline": True,
                }
            ],
            "timestamp": datetime.utcnow().isoformat(),
        }
        embeds.append(embed)

    if embeds:
        # Discord allows max 10 embeds per message
        for chunk in _chunk_list(embeds, 10):
            _send_webhook(url, embeds=chunk)

    return True


def _account_color(name: str) -> int:
    colors = {
        "IAN": 0xE1306C,
        "SLAYER": 0x833AB4,
        "POPEYE": 0xFCCC63,
    }
    return colors.get(name.upper(), 0x4DB8FF)


def _send_webhook(url: str, content: str = None, embeds: list = None) -> bool:
    payload = {}
    if content:
        payload["content"] = content
    if embeds:
        payload["embeds"] = embeds

    try:
        resp = requests.post(url, json=payload, timeout=15)
        if resp.status_code in (200, 204):
            return True
        else:
            print(f"[Discord] Webhook returned {resp.status_code}: {resp.text[:200]}")
            return False
    except Exception as e:
        print(f"[Discord] Error sending webhook: {e}")
        return False


def _send_as_file(url: str, account_name: str, content: str) -> bool:
    """Send content as a .txt file attachment."""
    try:
        filename = f"{account_name.lower()}_reels_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
        resp = requests.post(
            url,
            files={"file": (filename, content.encode("utf-8"), "text/plain")},
            timeout=20,
        )
        return resp.status_code in (200, 204)
    except Exception as e:
        print(f"[Discord] Error sending file: {e}")
        return False


def send_report_file_to_discord(report_path: str, webhook_url: str = None) -> bool:
    """Send the full report .txt file as a Discord attachment."""
    url = webhook_url or config.DISCORD_WEBHOOK_URL
    if not url:
        print("[Discord] No webhook URL set, skipping file send")
        return False

    try:
        with open(report_path, "rb") as f:
            content = f.read()

        filename = f"reels_report_{datetime.now().strftime('%Y%m%d_%H%M')}.txt"
        resp = requests.post(
            url,
            data={"content": "📄 **Full Report:**"},
            files={"file": (filename, content, "text/plain")},
            timeout=30,
        )
        if resp.status_code in (200, 204):
            print(f"[Discord] Report file sent: {filename}")
            return True
        else:
            print(f"[Discord] File send failed: {resp.status_code}: {resp.text[:200]}")
            return False
    except Exception as e:
        print(f"[Discord] Error sending report file: {e}")
        return False
