"""
igreelbot — Discord Control Bot
================================
Commands:
  !run                   — Start the scraper
  !stop                  — Stop the scraper
  !add <username>        — Add an Instagram account
  !remove <username>     — Remove an Instagram account
  !replace <old> <new>   — Rename/edit an account
  !list [page]           — List all accounts (20 per page)
  !clearall confirm      — Delete all accounts
  !status                — Show bot status
  !settings              — Show current settings (keys masked)
  !setkey <token>        — Update Apify API key (use in DMs)
  !setwebhook <url>      — Set Discord webhook URL
  !setmaxreels <n>       — Max reels per account
  !setminlikes <n>       — Min likes filter
  !sethours <n>          — Lookback window in hours
  !help                  — Show this command list

Required env:
  DISCORD_BOT_TOKEN — from Discord Developer Portal
"""

import asyncio
import os
import subprocess
import sys
from datetime import datetime

import discord
from config import get_setting, save_setting

# ── Config ────────────────────────────────────────────────────────────────────
TOKEN = os.getenv("DISCORD_BOT_TOKEN", "")
ACCOUNTS_FILE = os.path.join(os.path.dirname(__file__), "accounts.txt")
PREFIX = "!"

# ── Bot setup ─────────────────────────────────────────────────────────────────
intents = discord.Intents.default()
intents.message_content = True
client = discord.Client(intents=intents)

scraper_process: subprocess.Popen | None = None


# ── Account helpers ───────────────────────────────────────────────────────────
def read_accounts() -> list[str]:
    if not os.path.exists(ACCOUNTS_FILE):
        return []
    with open(ACCOUNTS_FILE, encoding="utf-8") as f:
        return [
            line.strip()
            for line in f
            if line.strip() and not line.startswith("#")
        ]


def write_accounts(accounts: list[str]) -> None:
    with open(ACCOUNTS_FILE, "w", encoding="utf-8") as f:
        for a in accounts:
            f.write(a + "\n")


def is_running() -> bool:
    global scraper_process
    return bool(scraper_process and scraper_process.poll() is None)


# ── Wait helper (background thread) ──────────────────────────────────────────
def _wait_for_scraper(channel):
    global scraper_process
    if scraper_process:
        scraper_process.wait()
        asyncio.run_coroutine_threadsafe(
            channel.send("✅ **Scraper finished! Report has been sent to Discord.**"),
            client.loop,
        )


# ── Events ────────────────────────────────────────────────────────────────────
@client.event
async def on_ready():
    print(f"[Discord Bot] Logged in as {client.user} (ID: {client.user.id})")
    print(f"[Discord Bot] Ready! Prefix: {PREFIX}")


@client.event
async def on_message(message: discord.Message):
    global scraper_process

    if message.author.bot:
        return

    content = message.content.strip()
    if not content.startswith(PREFIX):
        return

    parts = content[len(PREFIX):].split()
    if not parts:
        return

    cmd = parts[0].lower()
    args = parts[1:]

    # ── !run ──────────────────────────────────────────────────────────────────
    if cmd == "run":
        if is_running():
            await message.reply("⚠️ Scraper is already running! Use `!status` to check.")
            return

        accounts = read_accounts()
        if not accounts:
            await message.reply(
                "❌ No accounts found.\n"
                "Add one first with `!add <username>`."
            )
            return

        api_key = get_setting("APIFY_API_TOKEN", "")
        if not api_key:
            await message.reply(
                "❌ **Apify API key is not set!**\n"
                "Set it first with `!setkey <your_apify_token>`."
            )
            return

        await message.reply(
            f"🚀 **Scraper starting...**\n"
            f"📋 Accounts: **{len(accounts)}** — {', '.join(f'@{a}' for a in accounts)}\n"
            f"⏳ Please wait, results will be posted to Discord shortly!"
        )

        bot_dir = os.path.dirname(os.path.abspath(__file__))
        scraper_process = subprocess.Popen(
            [sys.executable, "main.py"],
            cwd=bot_dir,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        client.loop.run_in_executor(None, _wait_for_scraper, message.channel)

    # ── !stop ─────────────────────────────────────────────────────────────────
    elif cmd == "stop":
        if not is_running():
            await message.reply("ℹ️ No scraper is currently running.")
            return
        scraper_process.terminate()
        await message.reply("🛑 **Scraper stopped.**")

    # ── !add <username> ───────────────────────────────────────────────────────
    elif cmd == "add":
        if not args:
            await message.reply("❌ Usage: `!add <instagram_username>`")
            return
        username = args[0].lstrip("@").lower().strip()
        accounts = read_accounts()
        if username in [a.lower() for a in accounts]:
            await message.reply(f"⚠️ `@{username}` is already in the list.")
            return
        accounts.append(username)
        write_accounts(accounts)
        await message.reply(
            f"✅ `@{username}` added!\n"
            f"Total accounts: **{len(accounts)}**"
        )

    # ── !remove <username> ────────────────────────────────────────────────────
    elif cmd == "remove":
        if not args:
            await message.reply("❌ Usage: `!remove <instagram_username>`")
            return
        username = args[0].lstrip("@").lower().strip()
        accounts = read_accounts()
        new_accounts = [a for a in accounts if a.lower() != username]
        if len(new_accounts) == len(accounts):
            await message.reply(f"⚠️ `@{username}` not found in the list.")
            return
        write_accounts(new_accounts)
        await message.reply(
            f"🗑️ `@{username}` removed!\n"
            f"Total accounts: **{len(new_accounts)}**"
        )

    # ── !replace <old> <new> ──────────────────────────────────────────────────
    elif cmd == "replace":
        if len(args) < 2:
            await message.reply("❌ Usage: `!replace <old_username> <new_username>`")
            return
        old = args[0].lstrip("@").lower().strip()
        new = args[1].lstrip("@").lower().strip()
        accounts = read_accounts()
        lower_accounts = [a.lower() for a in accounts]
        if old not in lower_accounts:
            await message.reply(f"⚠️ `@{old}` not found in the list.")
            return
        if new in lower_accounts:
            await message.reply(f"⚠️ `@{new}` is already in the list.")
            return
        updated = [new if a.lower() == old else a for a in accounts]
        write_accounts(updated)
        await message.reply(f"✏️ `@{old}` → `@{new}` updated successfully!")

    # ── !list [page] ──────────────────────────────────────────────────────────
    elif cmd == "list":
        accounts = read_accounts()
        if not accounts:
            await message.reply("📋 No accounts found. Add one with `!add <username>`.")
            return

        PAGE_SIZE = 20
        total_pages = (len(accounts) + PAGE_SIZE - 1) // PAGE_SIZE
        try:
            page = max(1, int(args[0])) if args else 1
            page = min(page, total_pages)
        except ValueError:
            page = 1

        start = (page - 1) * PAGE_SIZE
        chunk = accounts[start : start + PAGE_SIZE]
        lines = "\n".join(f"{start+i+1}. @{a}" for i, a in enumerate(chunk))
        nav = f"Page {page}/{total_pages} — use `!list {page+1}` for next page" if total_pages > 1 else ""
        await message.reply(
            f"📋 **Instagram Accounts ({len(accounts)} total)**\n```\n{lines}\n```"
            + (f"\n{nav}" if nav else "")
        )

    # ── !clearall ─────────────────────────────────────────────────────────────
    elif cmd == "clearall":
        accounts = read_accounts()
        if not accounts:
            await message.reply("ℹ️ The list is already empty.")
            return
        if not args or args[0].lower() != "confirm":
            await message.reply(
                f"⚠️ This will delete **all {len(accounts)} accounts**!\n"
                f"Type `!clearall confirm` to proceed."
            )
            return
        write_accounts([])
        await message.reply(f"🗑️ All **{len(accounts)} accounts** have been cleared!")

    # ── !status ───────────────────────────────────────────────────────────────
    elif cmd == "status":
        accounts = read_accounts()
        running = is_running()
        api_key = get_setting("APIFY_API_TOKEN", "")
        webhook = get_setting("DISCORD_WEBHOOK_URL", "")

        key_status = f"✅ Set (...{api_key[-6:]})" if api_key else "❌ Not set"
        webhook_status = "✅ Set" if webhook else "❌ Not set"

        await message.reply(
            f"**📊 igreelbot Status**\n"
            f"Scraper: {'🟢 Running' if running else '🔴 Stopped'}\n"
            f"Accounts: **{len(accounts)}**\n"
            f"Apify Key: {key_status}\n"
            f"Webhook: {webhook_status}\n"
            f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        )

    # ── !settings ─────────────────────────────────────────────────────────────
    elif cmd == "settings":
        api_key = get_setting("APIFY_API_TOKEN", "")
        webhook = get_setting("DISCORD_WEBHOOK_URL", "")
        max_reels = get_setting("MAX_REELS", "10")
        min_likes = get_setting("MIN_LIKES", "0")
        hours = get_setting("HOURS_LOOKBACK", "24")

        key_display = f"...{api_key[-6:]}" if api_key else "Not set"
        webhook_display = f"...{webhook[-20:]}" if webhook else "Not set"

        await message.reply(
            f"**⚙️ Current Settings**\n"
            f"```\n"
            f"Apify Key   : {key_display}\n"
            f"Webhook URL : {webhook_display}\n"
            f"Max Reels   : {max_reels} per account\n"
            f"Min Likes   : {min_likes}\n"
            f"Lookback    : {hours} hours\n"
            f"```\n"
            f"Update with: `!setkey`, `!setwebhook`, `!setmaxreels`, `!setminlikes`, `!sethours`"
        )

    # ── !setkey <token> ───────────────────────────────────────────────────────
    elif cmd == "setkey":
        # Delete the command message first to minimise key exposure
        try:
            await message.delete()
        except discord.Forbidden:
            await message.channel.send(
                "⚠️ **Warning:** Bot does not have permission to delete messages.\n"
                "Your API key may be visible in channel history — use a private channel or DM for `!setkey`."
            )
        except Exception:
            pass

        if not args:
            await message.channel.send(
                "❌ Usage: `!setkey <apify_token>`\n"
                "⚠️ For security, use this command in **bot DMs or a private channel**.\n"
                "Get your token at: https://console.apify.com/account/integrations"
            )
            return
        token = args[0].strip()
        if len(token) < 10:
            await message.channel.send("❌ Token looks too short — please double-check it.")
            return
        save_setting("APIFY_API_TOKEN", token)
        await message.channel.send(
            f"✅ **Apify API key updated!**\n"
            f"Key (last 6 chars): `...{token[-6:]}`\n"
            f"You can now run the scraper with `!run`."
        )

    # ── !setwebhook <url> ─────────────────────────────────────────────────────
    elif cmd == "setwebhook":
        if not args:
            await message.reply(
                "❌ Usage: `!setwebhook <discord_webhook_url>`\n"
                "Get it from: Channel Settings → Integrations → Webhooks."
            )
            return
        url = args[0].strip()
        if not url.startswith("https://discord.com/api/webhooks/"):
            await message.reply(
                "❌ Invalid Discord webhook URL.\n"
                "It must start with `https://discord.com/api/webhooks/`."
            )
            return
        save_setting("DISCORD_WEBHOOK_URL", url)
        await message.reply("✅ **Discord webhook URL updated!** Reports will be sent there.")

    # ── !setmaxreels <n> ──────────────────────────────────────────────────────
    elif cmd == "setmaxreels":
        if not args or not args[0].isdigit():
            await message.reply("❌ Usage: `!setmaxreels <number>` (e.g. `!setmaxreels 20`)")
            return
        n = int(args[0])
        if n < 1 or n > 100:
            await message.reply("❌ Value must be between 1 and 100.")
            return
        save_setting("MAX_REELS", str(n))
        await message.reply(f"✅ Max reels per account set to **{n}**.")

    # ── !setminlikes <n> ──────────────────────────────────────────────────────
    elif cmd == "setminlikes":
        if not args or not args[0].isdigit():
            await message.reply("❌ Usage: `!setminlikes <number>` (e.g. `!setminlikes 500`)")
            return
        n = int(args[0])
        save_setting("MIN_LIKES", str(n))
        await message.reply(f"✅ Minimum likes filter set to **{n}**.")

    # ── !sethours <n> ─────────────────────────────────────────────────────────
    elif cmd == "sethours":
        if not args or not args[0].isdigit():
            await message.reply("❌ Usage: `!sethours <number>` (e.g. `!sethours 48`)")
            return
        n = int(args[0])
        if n < 1 or n > 168:
            await message.reply("❌ Value must be between 1 and 168 (1 week max).")
            return
        save_setting("HOURS_LOOKBACK", str(n))
        await message.reply(f"✅ Lookback window set to **{n} hours**.")

    # ── !help ─────────────────────────────────────────────────────────────────
    elif cmd == "help":
        await message.reply(
            "**🤖 igreelbot Commands**\n\n"
            "**Scraper Control:**\n"
            "`!run` — Start the scraper\n"
            "`!stop` — Stop the scraper\n"
            "`!status` — Show bot status\n\n"
            "**Account Management:**\n"
            "`!add <username>` — Add an Instagram account\n"
            "`!remove <username>` — Remove an account\n"
            "`!replace <old> <new>` — Edit/rename an account\n"
            "`!list [page]` — List all accounts (20 per page)\n"
            "`!clearall confirm` — Delete all accounts\n\n"
            "**Settings:**\n"
            "`!settings` — View current settings\n"
            "`!setkey <token>` — Set Apify API key ⚠️ use in DMs\n"
            "`!setwebhook <url>` — Set Discord webhook URL\n"
            "`!setmaxreels <n>` — Max reels per account (default: 10)\n"
            "`!setminlikes <n>` — Minimum likes filter (default: 0)\n"
            "`!sethours <n>` — Lookback window in hours (default: 24)\n\n"
            "`!help` — Show this message"
        )


# ── Run ───────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not TOKEN:
        print("[ERROR] DISCORD_BOT_TOKEN is not set!")
        print("        Add DISCORD_BOT_TOKEN to your environment secrets.")
        sys.exit(1)
    print("[Discord Bot] Starting igreelbot...")
    client.run(TOKEN)
