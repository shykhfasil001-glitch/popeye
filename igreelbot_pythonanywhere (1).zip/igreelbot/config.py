"""
config.py — Settings loader
Priority (highest first):
  1. settings.json  (Discord bot se update hota hai)
  2. .env file
  3. Default values
"""
import os
import json
from dotenv import load_dotenv

load_dotenv()

# ── settings.json (runtime overrides) ────────────────────────────────────────
_SETTINGS_FILE = os.path.join(os.path.dirname(__file__), "settings.json")


def _load_settings() -> dict:
    if os.path.exists(_SETTINGS_FILE):
        try:
            with open(_SETTINGS_FILE, encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {}
    return {}


def save_setting(key: str, value) -> None:
    """Discord bot se call hota hai — ek setting update karo."""
    data = _load_settings()
    data[key] = value
    with open(_SETTINGS_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)


def get_setting(key: str, default=None):
    """settings.json phir env phir default."""
    s = _load_settings()
    if key in s:
        return s[key]
    return os.getenv(key, default)


# ── Apify ─────────────────────────────────────────────────────────────────────
APIFY_API_TOKEN: str = get_setting("APIFY_API_TOKEN", "")

# ── Discord ───────────────────────────────────────────────────────────────────
DISCORD_WEBHOOK_URL: str = get_setting("DISCORD_WEBHOOK_URL", "")

# ── Instagram Accounts ────────────────────────────────────────────────────────
# accounts.txt se padho (one username per line)
_accounts_file = os.path.join(os.path.dirname(__file__), "accounts.txt")
if os.path.exists(_accounts_file):
    with open(_accounts_file, encoding="utf-8") as _f:
        _usernames = [
            line.strip()
            for line in _f
            if line.strip() and not line.startswith("#")
        ]
else:
    _raw = os.getenv("INSTAGRAM_USERNAMES", "")
    _usernames = [u.strip() for u in _raw.split(",") if u.strip()]

INSTAGRAM_ACCOUNTS = {u.upper(): u for u in _usernames}

# ── Scraper ───────────────────────────────────────────────────────────────────
MAX_REELS_PER_ACCOUNT: int = int(get_setting("MAX_REELS", "10"))
MIN_LIKES_THRESHOLD: int = int(get_setting("MIN_LIKES", "0"))
HOURS_LOOKBACK: int = int(get_setting("HOURS_LOOKBACK", "24"))

# ── Report ────────────────────────────────────────────────────────────────────
REPORT_OUTPUT_FILE: str = get_setting("REPORT_FILE", "reels_report.txt")
# SEND_TO_DISCORD: safe coerce — settings.json may store bool or str
_send_raw = get_setting("SEND_TO_DISCORD", "true")
SEND_TO_DISCORD: bool = _send_raw if isinstance(_send_raw, bool) else str(_send_raw).lower() == "true"

# ── Retry ─────────────────────────────────────────────────────────────────────
MAX_RETRIES = 3
RETRY_DELAY = 5
