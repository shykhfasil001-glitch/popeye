"""
igreelbot — Instagram Reels Scraper & Reporter
Scrapes reels from configured accounts, collects full metrics
(views, likes, comments, ER, duration, posted time), and sends
a formatted report to Discord.

Usage:
    python main.py               # Run once
    python main.py --no-discord  # Run without sending to Discord
    python main.py --accounts IAN SLAYER   # Only specific accounts
"""
import sys
import time
import argparse
from datetime import datetime

import config
from src.apify_scraper import scrape_account, ReelData
from src.distribution import apply_filters
from src.report_generator import generate_report, save_report, print_report
from src.discord_sender import send_report_to_discord, send_full_report_embed, send_report_file_to_discord


def parse_args():
    parser = argparse.ArgumentParser(description="igreelbot — Instagram Reels Tracker")
    parser.add_argument(
        "--no-discord",
        action="store_true",
        help="Skip sending to Discord",
    )
    parser.add_argument(
        "--accounts",
        nargs="+",
        help="Only scrape specific accounts (by display name, e.g. IAN SLAYER)",
        default=None,
    )
    parser.add_argument(
        "--max-reels",
        type=int,
        default=config.MAX_REELS_PER_ACCOUNT,
        help=f"Max reels per account (default: {config.MAX_REELS_PER_ACCOUNT})",
    )
    parser.add_argument(
        "--min-likes",
        type=int,
        default=config.MIN_LIKES_THRESHOLD,
        help=f"Min likes filter (default: {config.MIN_LIKES_THRESHOLD})",
    )
    parser.add_argument(
        "--output",
        type=str,
        default=config.REPORT_OUTPUT_FILE,
        help=f"Output report file (default: {config.REPORT_OUTPUT_FILE})",
    )
    return parser.parse_args()


def run(args) -> dict[str, list[ReelData]]:
    accounts = config.INSTAGRAM_ACCOUNTS

    # Filter to requested accounts only
    if args.accounts:
        requested = {a.upper() for a in args.accounts}
        accounts = {k: v for k, v in accounts.items() if k.upper() in requested}

    if not accounts:
        print("[ERROR] No accounts configured. Check your .env file.")
        sys.exit(1)

    # Override config from args
    config.MIN_LIKES_THRESHOLD = args.min_likes
    config.MAX_REELS_PER_ACCOUNT = args.max_reels

    all_results: dict[str, list[ReelData]] = {}

    for display_name, username in accounts.items():
        if not username:
            print(f"[SKIP] {display_name}: no username set in .env")
            continue

        print(f"\n{'='*60}")
        print(f"Processing: {display_name} (@{username})")
        print(f"{'='*60}")

        try:
            raw_reels = scrape_account(username, max_posts=args.max_reels)
            filtered = apply_filters(raw_reels)
            all_results[display_name] = filtered
            print(f"[OK] {display_name}: {len(filtered)} reels after filtering")
        except Exception as e:
            print(f"[ERROR] Failed to scrape {display_name} (@{username}): {e}")
            all_results[display_name] = []

    return all_results


def main():
    args = parse_args()

    print(f"\n{'='*60}")
    print(f"igreelbot — Starting at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print(f"Accounts: {list(config.INSTAGRAM_ACCOUNTS.keys())}")
    print(f"Max reels: {args.max_reels} | Min likes: {args.min_likes}")
    print(f"Lookback: {config.HOURS_LOOKBACK}h")
    print(f"{'='*60}\n")

    # Scrape all accounts
    all_results = run(args)

    # Print report to console
    print_report(all_results)

    # Save report to file
    output_path = save_report(all_results, args.output)
    print(f"\n[OK] Report saved: {output_path}")

    # Send to Discord
    send_discord = config.SEND_TO_DISCORD and not args.no_discord
    if send_discord:
        print("\n[Discord] Sending reports...")

        # Send single summary embed
        send_full_report_embed(all_results)
        time.sleep(1)

        # Send full report as .txt file attachment
        send_report_file_to_discord(output_path)

        print("[Discord] Done sending reports")
    else:
        print("[Discord] Skipped (--no-discord or SEND_TO_DISCORD=false)")

    print(f"\n[DONE] Finished at {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")


if __name__ == "__main__":
    main()
